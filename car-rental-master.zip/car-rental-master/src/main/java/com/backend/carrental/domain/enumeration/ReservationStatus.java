package com.backend.carrental.domain.enumeration;

public enum ReservationStatus {

    CREATED, CANCELED, DONE
}
