package com.backend.carrental.domain.enumeration;

public enum UserRole {

    ROLE_CUSTOMER, ROLE_ADMIN, ROLE_CUSTOMER_SERVICE, ROLE_MANAGER
}
